package tests;

public interface Work {
	public void execute();
}
